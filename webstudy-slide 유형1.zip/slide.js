window.onload = function(){
var currentIndex = 0;              //현재 이미지
setInterval(function(){
    if(currentIndex < 2) {
        currentIndex++;
    } else {
        currentIndex = 0;
    }
    var slidePosition = currentIndex * (-360)+"px";

    $(".slideList").animate({top:slidePosition},400);

},3000);       //3초에 한번 씩 함수 interval간격을 set설정한다..
}




